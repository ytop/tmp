import numpy as np
import torch
from torchvision.ops import roi_align 


class TorchNet(torch.nn.Module):
    def __init__(self, **kwargs):
        super(TorchNet, self).__init__()
        self.kwargs = kwargs
        self.output_size = kwargs.get('output_size')
        self.sampling_ratio = kwargs.get('sampling_ratio')
        self.spatial_scale = kwargs.get('spatial_scale')
        self.aligned = kwargs.get('aligned')

    def forward(self, input_x, boxes):
        return roi_align(input_x, boxes, spatial_scale=self.spatial_scale,
                output_size=self.output_size, sampling_ratio=self.sampling_ratio,
                aligned=self.aligned)

# HQ test case
print('****************** HQ test case ******************')

pooled_height, pooled_width, spatial_scale, sample_num = 2, 2, 0.5, 2
sampling_ratio = 2
x = torch.tensor(np.array( [[[[1., 2.], [3., 4.]]]]).astype(np.float32))
rois = torch.tensor(np.array([[0, 0.2, 0.3, 0.2, 0.3]]).astype(np.float32))
print("x ", x)
print("rois ", rois)
output_size = (pooled_height, pooled_width)
torch_kwargs = dict(output_size=output_size, spatial_scale=spatial_scale,
        sampling_ratio=2, aligned=True)
torch_net = TorchNet(**torch_kwargs) 
torch_out = torch_net(x, rois)
print("torch output ", torch_out)

